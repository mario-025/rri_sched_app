from app.models.user import User
from app.dev.common import app_context, print_rows


def main():
    with app_context():
        users = User.query.order_by(User.fullname.asc()).all()
        rows = [
            (
                user.id,
                user.fullname,
                user.username,
                user.email or "-",
                user.phone_number or "-",
                user.score,
                "yes" if user.telegram_verified else "no",
                user.telegram_id or "-"
            )
            for user in users
        ]

    print_rows(
        [
            "id",
            "fullname",
            "username",
            "email",
            "phone",
            "score",
            "telegram",
            "telegram_id"
        ],
        rows
    )


if __name__ == "__main__":
    main()
