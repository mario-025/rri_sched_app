import argparse
import datetime

from app.models.schedule import Schedule
from app.dev.common import app_context, positive_int, print_rows


def parse_args():
    parser = argparse.ArgumentParser(
        description="List schedules with joined user and shift data."
    )
    parser.add_argument("--date", help="Filter by date, format YYYY-MM-DD.")
    parser.add_argument("--user-id", type=positive_int, help="Filter by user id.")
    parser.add_argument("--limit", type=positive_int, default=100)
    return parser.parse_args()


def main():
    args = parse_args()

    with app_context():
        query = Schedule.query

        if args.date:
            try:
                work_date = datetime.date.fromisoformat(args.date)
            except ValueError:
                raise SystemExit("--date must use YYYY-MM-DD format")

            query = query.filter(Schedule.work_date == work_date)

        if args.user_id:
            query = query.filter(Schedule.user_id == args.user_id)

        schedules = (
            query
            .order_by(Schedule.work_date.asc(), Schedule.shift_id.asc())
            .limit(args.limit)
            .all()
        )

        rows = [
            (
                schedule.id,
                schedule.work_date.isoformat(),
                schedule.schedule_type,
                schedule.user.fullname if schedule.user else "-",
                schedule.shift.shift_name if schedule.shift else "-",
                (
                    f"{schedule.shift.start_time.strftime('%H:%M')}-"
                    f"{schedule.shift.end_time.strftime('%H:%M')}"
                    if schedule.shift else "-"
                )
            )
            for schedule in schedules
        ]

    print_rows(
        ["id", "date", "type", "user", "shift", "time"],
        rows
    )


if __name__ == "__main__":
    main()
