from app.dev.common import app_context, print_rows
from app.models.user import User


def main():
    with app_context():
        users = (
            User.query
            .filter(
                (User.telegram_id.isnot(None))
                | (User.telegram_verified.is_(True))
                | (User.telegram_enabled.is_(True))
            )
            .order_by(User.fullname.asc())
            .all()
        )

        rows = [
            (
                user.id,
                user.fullname,
                user.telegram_id or "-",
                user.telegram_username or "-",
                "yes" if user.telegram_verified else "no",
                "yes" if user.telegram_enabled else "no",
                user.telegram_verified_at.strftime("%Y-%m-%d %H:%M")
                if user.telegram_verified_at else "-"
            )
            for user in users
        ]

    print_rows(
        [
            "user_id",
            "fullname",
            "telegram_id",
            "username",
            "verified",
            "enabled",
            "verified_at"
        ],
        rows
    )


if __name__ == "__main__":
    main()
