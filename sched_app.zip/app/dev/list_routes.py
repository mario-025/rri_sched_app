from app.dev.common import app_context, print_rows


def main():
    with app_context() as app:
        rows = []
        for rule in sorted(app.url_map.iter_rules(), key=lambda item: item.rule):
            methods = ",".join(sorted(rule.methods - {"HEAD", "OPTIONS"}))
            rows.append((rule.endpoint, methods, rule.rule))

    print_rows(["endpoint", "methods", "rule"], rows)


if __name__ == "__main__":
    main()
