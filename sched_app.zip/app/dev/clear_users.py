"""
Delete all users from database dan force disconnect telegram connections.
Berguna untuk reset development database.
"""

import argparse

from app.models.user import User
from app.models.schedule import Schedule
from app.models.telegram_notification import TelegramNotification
from app.dev.common import add_yes_flag, app_context, db, require_yes


def parse_args():
    parser = argparse.ArgumentParser(
        description="Delete all users and force disconnect telegram."
    )
    parser.add_argument(
        "--cascade",
        action="store_true",
        help="Also delete all schedules related to users (cascade delete)."
    )
    add_yes_flag(parser)
    return parser.parse_args()


def main():
    args = parse_args()
    require_yes(args, "delete all users")

    with app_context():
        try:
            # Count users
            total_users = User.query.count()
            
            if total_users == 0:
                print("Tidak ada pengguna untuk dihapus.")
                return
            
            print(f"Akan menghapus {total_users} pengguna...")
            
            # Jika cascade, hapus schedules terlebih dahulu
            if args.cascade:
                total_schedules = Schedule.query.delete()
                total_notifications = TelegramNotification.query.delete()
                print(f"Deleted schedules: {total_schedules}")
                print(f"Deleted telegram notifications: {total_notifications}")
            
            # Hapus semua users
            deleted_users = User.query.delete()
            
            db.session.commit()
            
            print(f"✓ Deleted users: {deleted_users}")
            print("✓ Semua koneksi telegram dipaksa terputus")
            print("✓ Database users sudah dikosongkan")
            
        except Exception as e:
            db.session.rollback()
            raise SystemExit(f"Error: {e}")


if __name__ == "__main__":
    main()
