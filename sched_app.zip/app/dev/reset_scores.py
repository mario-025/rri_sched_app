import argparse

from app.models.schedule import Schedule
from app.models.user import User
from app.dev.common import add_yes_flag, app_context, db, print_rows, require_yes


def parse_args():
    parser = argparse.ArgumentParser(
        description="Reset or recalculate user scores."
    )
    parser.add_argument(
        "--recalculate",
        action="store_true",
        help="Recalculate scores from existing schedules instead of setting all to 0."
    )
    add_yes_flag(parser)
    return parser.parse_args()


def main():
    args = parse_args()
    action = "recalculate scores" if args.recalculate else "reset scores"
    require_yes(args, action)

    with app_context():
        users = User.query.all()

        for user in users:
            user.score = 0

        if args.recalculate:
            schedules = Schedule.query.all()
            for schedule in schedules:
                if schedule.user and schedule.shift:
                    schedule.user.score += schedule.shift.score

        db.session.commit()

        rows = [
            (user.id, user.fullname, user.username, user.score)
            for user in User.query.order_by(User.fullname.asc()).all()
        ]

    print(f"Done: {action}.")
    print_rows(["id", "fullname", "username", "score"], rows)


if __name__ == "__main__":
    main()
