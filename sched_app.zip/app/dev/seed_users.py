"""
Seed database dengan sample users untuk development dan testing.
Berguna untuk quick setup development environment.
"""

import argparse
from werkzeug.security import generate_password_hash

from app.models.user import User
from app.dev.common import add_yes_flag, app_context, db, require_yes


# Sample data untuk seed
SAMPLE_USERS = [
    {
        'fullname': 'Budi Santoso',
        'username': 'budi',
        'email': 'budi@example.com',
        'phone_number': '081234567890',
        'password': 'password123'
    },
    {
        'fullname': 'Siti Nurhaliza',
        'username': 'siti',
        'email': 'siti@example.com',
        'phone_number': '081234567891',
        'password': 'password123'
    },
    {
        'fullname': 'Ahmad Wijaya',
        'username': 'ahmad',
        'email': 'ahmad@example.com',
        'phone_number': '081234567892',
        'password': 'password123'
    },
    {
        'fullname': 'Jona Pratama',
        'username': 'jona',
        'email': 'jona@example.com',
        'phone_number': '081234567893',
        'password': 'password123'
    },
    {
        'fullname': 'Joni Suryanto',
        'username': 'joni',
        'email': 'joni@example.com',
        'phone_number': '081234567894',
        'password': 'password123'
    },
    {
        'fullname': 'Jeni Kusuma',
        'username': 'jeni',
        'email': 'jeni@example.com',
        'phone_number': '081234567895',
        'password': 'password123'
    },
    {
        'fullname': 'Keith Mahardika',
        'username': 'keith',
        'email': 'keith@example.com',
        'phone_number': '081234567896',
        'password': 'password123'
    },
    {
        'fullname': 'Kate Wijaya',
        'username': 'kate',
        'email': 'kate@example.com',
        'phone_number': '081234567897',
        'password': 'password123'
    },
    {
        'fullname': 'Kean Pratama',
        'username': 'kean',
        'email': 'kean@example.com',
        'phone_number': '081234567898',
        'password': 'password123'
    },
    {
        'fullname': 'Rudi Hartono',
        'username': 'rudi',
        'email': 'rudi@example.com',
        'phone_number': '081234567899',
        'password': 'password123'
    },
    {
        'fullname': 'Putri Ramadhani',
        'username': 'putri',
        'email': 'putri@example.com',
        'phone_number': '081234567800',
        'password': 'password123'
    },
    {
        'fullname': 'Tomo Kusuma',
        'username': 'tomo',
        'email': 'tomo@example.com',
        'phone_number': '081234567801',
        'password': 'password123'
    },
    {
        'fullname': 'Widy Santoso',
        'username': 'widy',
        'email': 'widy@example.com',
        'phone_number': '081234567802',
        'password': 'password123'
    },
    {
        'fullname': 'Mirna Sulistya',
        'username': 'mirna',
        'email': 'mirna@example.com',
        'phone_number': '081234567803',
        'password': 'password123'
    },
    {
        'fullname': 'Evi Kusuma',
        'username': 'evi',
        'email': 'evi@example.com',
        'phone_number': '081234567804',
        'password': 'password123'
    },
    {
        'fullname': 'Rina Wijaya',
        'username': 'rina',
        'email': 'rina@example.com',
        'phone_number': '081234567805',
        'password': 'password123'
    },
    {
        'fullname': 'Seno Pratama',
        'username': 'seno',
        'email': 'seno@example.com',
        'phone_number': '081234567806',
        'password': 'password123'
    },
    {
        'fullname': 'Bam Susanto',
        'username': 'bam',
        'email': 'bam@example.com',
        'phone_number': '081234567807',
        'password': 'password123'
    },
]


def parse_args():
    parser = argparse.ArgumentParser(
        description="Seed database dengan sample users untuk testing."
    )
    parser.add_argument(
        "--count",
        type=int,
        default=len(SAMPLE_USERS),
        help=f"Jumlah users yang akan ditambahkan (default: {len(SAMPLE_USERS)})"
    )
    add_yes_flag(parser)
    return parser.parse_args()


def main():
    args = parse_args()
    require_yes(args, "seed database dengan users")

    with app_context():
        try:
            # Check existing users
            existing_count = User.query.count()
            
            if existing_count > 0:
                print(f"⚠ Database sudah memiliki {existing_count} users.")
                print("  Jalankan dengan: clear_users --yes")
                print("  Sebelum seed users baru.")
                return
            
            # Determine how many users to add
            users_to_add = min(args.count, len(SAMPLE_USERS))
            
            print(f"Menambahkan {users_to_add} sample users...")
            
            # Create users
            for i in range(users_to_add):
                user_data = SAMPLE_USERS[i]
                
                user = User(
                    fullname=user_data['fullname'],
                    username=user_data['username'],
                    email=user_data['email'],
                    phone_number=user_data['phone_number'],
                    password=generate_password_hash(user_data['password']),
                    score=0
                )
                
                db.session.add(user)
            
            db.session.commit()
            
            print(f"\n✓ Berhasil menambahkan {users_to_add} users")
            print("\nSample Credentials:")
            print("-" * 50)
            for i in range(users_to_add):
                user = SAMPLE_USERS[i]
                print(f"  Username: {user['username']:15} | Password: {user['password']}")
            print("-" * 50)
            print("\nTips:")
            print("- Semua user memiliki password: 'password123'")
            print("- Gunakan username untuk login")
            print("- User score dimulai dari 0")
            print("- Semua user belum terhubung ke telegram")
            
        except Exception as e:
            db.session.rollback()
            raise SystemExit(f"Error: {e}")


if __name__ == "__main__":
    main()
