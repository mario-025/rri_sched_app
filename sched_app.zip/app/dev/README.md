# Dev Debug Scripts

Run these scripts from the project root with the virtualenv Python:

```powershell
.\venv\Scripts\python.exe -m app.dev.app_health
```

All dev scripts disable Telegram bot startup by default so debugging does not
start another polling instance.

## Read-only checks

```powershell
.\venv\Scripts\python.exe -m app.dev.app_health
.\venv\Scripts\python.exe -m app.dev.list_routes
.\venv\Scripts\python.exe -m app.dev.check_templates
.\venv\Scripts\python.exe -m app.dev.get_all_users
.\venv\Scripts\python.exe -m app.dev.get_all_shifts
.\venv\Scripts\python.exe -m app.dev.get_all_schedules --limit 50
.\venv\Scripts\python.exe -m app.dev.get_all_schedules --date 2026-05-20
.\venv\Scripts\python.exe -m app.dev.check_telegram_state
.\venv\Scripts\python.exe -m app.dev.get_telegram_notifications --limit 50
.\venv\Scripts\python.exe -m app.dev.preview_schedule_generation --year 2026 --month 5 --days-off 5,6
```

## Database-changing actions

These require `--yes` on purpose.

```powershell
.\venv\Scripts\python.exe -m app.dev.reset_scores --yes
.\venv\Scripts\python.exe -m app.dev.reset_scores --recalculate --yes
.\venv\Scripts\python.exe -m app.dev.clear_schedules --reset-scores --yes
.\venv\Scripts\python.exe -m app.dev.generate_schedules --year 2026 --month 6 --schedule-type debug --save --yes
```

## User Management

### Seed Users (Tambah sample users)
```powershell
.\venv\Scripts\python.exe -m app.dev.seed_users --yes
```

**Fitur:**
- Menambahkan 18 sample users ke database
- Semua user memiliki password: `password123`
- User score dimulai dari 0
- Berguna untuk quick development setup

**Sample Users yang Ditambahkan:**
- Budi Santoso (username: budi)
- Siti Nurhaliza (username: siti)
- Ahmad Wijaya (username: ahmad)
- Jona Pratama (username: jona)
- Joni Suryanto (username: joni)
- Jeni Kusuma (username: jeni)
- Keith Mahardika (username: keith)
- Kate Wijaya (username: kate)
- Kean Pratama (username: kean)
- Rudi Hartono (username: rudi)
- Putri Ramadhani (username: putri)
- Tomo Kusuma (username: tomo)
- Widy Santoso (username: widy)
- Mirna Sulistya (username: mirna)
- Evi Kusuma (username: evi)
- Rina Wijaya (username: rina)
- Seno Pratama (username: seno)
- Bam Susanto (username: bam)

**Opsi:**
```powershell
# Tambah custom jumlah users (max 18)
.\venv\Scripts\python.exe -m app.dev.seed_users --count 10 --yes
```

### Clear Users (Hapus semua users)
```powershell
.\venv\Scripts\python.exe -m app.dev.clear_users --yes
```

**Fitur:**
- Hapus semua user dari database
- Force disconnect semua koneksi telegram
- Hapus relationships ke schedules (optional)

**Opsi:**
```powershell
# Hapus users + cascade delete schedules
.\venv\Scripts\python.exe -m app.dev.clear_users --cascade --yes

# Hanya hapus users, keep schedules
.\venv\Scripts\python.exe -m app.dev.clear_users --yes
```

## Development Workflow Examples

### 1. Fresh Database Setup
```powershell
# Clear everything
.\venv\Scripts\python.exe -m app.dev.clear_schedules --reset-scores --yes
.\venv\Scripts\python.exe -m app.dev.clear_users --yes

# Seed fresh users
.\venv\Scripts\python.exe -m app.dev.seed_users --yes

# Generate schedules
.\venv\Scripts\python.exe -m app.dev.generate_schedules --year 2026 --month 6 --schedule-type debug --save --yes
```

### 2. Test Schedule Generation
```powershell
# Preview tanpa save
.\venv\Scripts\python.exe -m app.dev.preview_schedule_generation --year 2026 --month 6 --days-off 5,6

# Save jika OK
.\venv\Scripts\python.exe -m app.dev.generate_schedules --year 2026 --month 6 --schedule-type test --save --yes
```

### 3. Reset User Scores
```powershell
# Set semua user score = 0
.\venv\Scripts\python.exe -m app.dev.reset_scores --yes

# Recalculate scores dari schedules
.\venv\Scripts\python.exe -m app.dev.reset_scores --recalculate --yes
```
