from jinja2 import TemplateSyntaxError

from app.dev.common import app_context, print_rows


def main():
    with app_context() as app:
        templates = sorted(
            template
            for template in app.jinja_env.list_templates()
            if template.endswith(".html")
        )
        rows = []
        failed = False

        for template_name in templates:
            try:
                app.jinja_env.get_template(template_name)
                rows.append((template_name, "ok", "-"))
            except TemplateSyntaxError as e:
                failed = True
                rows.append((template_name, "error", f"line {e.lineno}: {e.message}"))

    print_rows(["template", "status", "detail"], rows)

    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
