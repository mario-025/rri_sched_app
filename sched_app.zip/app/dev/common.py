import argparse
import os
from contextlib import contextmanager


# Dev scripts should not start Telegram polling/notifier unless explicitly asked.
os.environ.setdefault("TELEGRAM_BOT_ENABLED", "false")

from app import create_app
from app.config.database import db


@contextmanager
def app_context():
    app = create_app()
    with app.app_context():
        yield app


def add_yes_flag(parser):
    parser.add_argument(
        "--yes",
        action="store_true",
        help="Confirm a database-changing action."
    )


def require_yes(args, action):
    if not getattr(args, "yes", False):
        raise SystemExit(
            f"Refusing to {action}. Re-run with --yes if you are sure."
        )


def positive_int(value):
    try:
        parsed = int(value)
    except ValueError:
        raise argparse.ArgumentTypeError("must be an integer")

    if parsed < 1:
        raise argparse.ArgumentTypeError("must be greater than 0")

    return parsed


def print_rows(headers, rows):
    rows = list(rows)
    widths = [len(header) for header in headers]

    for row in rows:
        for index, value in enumerate(row):
            widths[index] = max(widths[index], len(str(value)))

    fmt = " | ".join(f"{{:<{width}}}" for width in widths)
    separator = "-+-".join("-" * width for width in widths)

    print(fmt.format(*headers))
    print(separator)

    for row in rows:
        print(fmt.format(*(str(value) for value in row)))

    print(f"\nTotal: {len(rows)}")
