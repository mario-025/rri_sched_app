import argparse

from app.models.schedule import Schedule
from app.models.telegram_notification import TelegramNotification
from app.dev.common import add_yes_flag, app_context, db, require_yes


def parse_args():
    parser = argparse.ArgumentParser(
        description="Delete schedules for debugging."
    )
    parser.add_argument(
        "--reset-scores",
        action="store_true",
        help="Set all user scores to 0 after schedules are deleted."
    )
    add_yes_flag(parser)
    return parser.parse_args()


def main():
    args = parse_args()
    require_yes(args, "delete all schedules")

    with app_context():
        try:
            total_notifications = TelegramNotification.query.delete()
            total_schedules = Schedule.query.delete()

            if args.reset_scores:
                from app.models.user import User

                for user in User.query.all():
                    user.score = 0

            db.session.commit()
            print(f"Deleted schedules: {total_schedules}")
            print(f"Deleted telegram notification logs: {total_notifications}")
            if args.reset_scores:
                print("User scores reset to 0.")
        except Exception as e:
            db.session.rollback()
            raise SystemExit(f"Error: {e}")


if __name__ == "__main__":
    main()
