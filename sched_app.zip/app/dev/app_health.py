from app.dev.common import app_context, db, print_rows
from app.models.schedule import Schedule
from app.models.shift import Shift
from app.models.shift_pattern import ShiftPattern
from app.models.telegram_notification import TelegramNotification
from app.models.user import User


def safe_count(model):
    try:
        return model.query.count()
    except Exception as e:
        return f"error: {e}"


def main():
    with app_context():
        try:
            db.session.execute(db.text("SELECT 1"))
            database_status = "ok"
        except Exception as e:
            database_status = f"error: {e}"

        rows = [
            ("database", database_status),
            ("users", safe_count(User)),
            ("shifts", safe_count(Shift)),
            ("shift_patterns", safe_count(ShiftPattern)),
            ("schedules", safe_count(Schedule)),
            ("telegram_notifications", safe_count(TelegramNotification)),
        ]

    print_rows(["check", "result"], rows)


if __name__ == "__main__":
    main()
