import argparse

from app.dev.common import app_context, positive_int, print_rows
from app.models.telegram_notification import TelegramNotification


def parse_args():
    parser = argparse.ArgumentParser(
        description="List Telegram notification logs."
    )
    parser.add_argument("--status", choices=["pending", "sent", "failed"])
    parser.add_argument("--user-id", type=positive_int)
    parser.add_argument("--limit", type=positive_int, default=100)
    return parser.parse_args()


def main():
    args = parse_args()

    with app_context():
        query = TelegramNotification.query

        if args.status:
            query = query.filter(TelegramNotification.status == args.status)

        if args.user_id:
            query = query.filter(TelegramNotification.user_id == args.user_id)

        notifications = (
            query
            .order_by(TelegramNotification.created_at.desc())
            .limit(args.limit)
            .all()
        )

        rows = [
            (
                item.id,
                item.user_id,
                item.schedule_id or "-",
                item.notification_type,
                item.status,
                item.sent_at.strftime("%Y-%m-%d %H:%M:%S") if item.sent_at else "-",
                (item.error_message or "-")[:80]
            )
            for item in notifications
        ]

    print_rows(
        ["id", "user_id", "schedule_id", "type", "status", "sent_at", "error"],
        rows
    )


if __name__ == "__main__":
    main()
