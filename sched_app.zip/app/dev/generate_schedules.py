import argparse
import datetime

from app.models.schedule import Schedule
from app.dev.common import add_yes_flag, app_context, db, print_rows, require_yes
from app.services.scheduler import generate_schedule


def parse_args():
    parser = argparse.ArgumentParser(
        description="Preview or save generated schedules."
    )
    parser.add_argument("--year", type=int, default=datetime.date.today().year)
    parser.add_argument("--month", type=int, default=datetime.date.today().month)
    parser.add_argument(
        "--days-off",
        default="",
        help="Comma-separated weekday indexes to skip. Monday=0, Sunday=6."
    )
    parser.add_argument(
        "--schedule-type",
        default="debug",
        help="Schedule type used when saving generated rows."
    )
    parser.add_argument("--save", action="store_true", help="Save preview to database.")
    add_yes_flag(parser)
    return parser.parse_args()


def parse_days_off(value):
    if not value:
        return []

    return [int(item.strip()) for item in value.split(",") if item.strip()]


def save_schedule(data, schedule_type):
    for item in data:
        db.session.add(
            Schedule(
                user_id=item["user_id"],
                shift_id=item["shift_id"],
                work_date=datetime.date.fromisoformat(item["work_date"]),
                schedule_type=schedule_type
            )
        )
    db.session.commit()


def main():
    args = parse_args()
    days_off = parse_days_off(args.days_off)

    with app_context():
        result = generate_schedule(args.year, args.month, days_off=days_off)
        if result.get("error"):
            raise SystemExit(result["error"])

        schedules = result.get("schedules", [])
        rows = [
            (
                item["work_date"],
                item["day"],
                item["user"],
                item["shift"],
                item["pattern"],
                item["user_score"]
            )
            for item in schedules
        ]

        print_rows(
            ["date", "day", "user", "shift", "pattern", "score_after"],
            rows
        )

        if args.save:
            require_yes(args, "save generated schedules")
            try:
                save_schedule(schedules, args.schedule_type)
                print("Generated schedules saved.")
            except Exception as e:
                db.session.rollback()
                raise SystemExit(f"Error: {e}")
        else:
            db.session.rollback()


if __name__ == "__main__":
    main()
