import argparse
import datetime

from app.dev.common import app_context, print_rows
from app.config.database import db
from app.services.scheduler import generate_schedule


def parse_args():
    parser = argparse.ArgumentParser(
        description="Preview schedule generation without saving anything."
    )
    parser.add_argument("--year", type=int, default=datetime.date.today().year)
    parser.add_argument("--month", type=int, default=datetime.date.today().month)
    parser.add_argument(
        "--days-off",
        default="",
        help="Comma-separated weekday indexes to skip. Monday=0, Sunday=6."
    )
    return parser.parse_args()


def parse_days_off(value):
    if not value:
        return []

    return [int(item.strip()) for item in value.split(",") if item.strip()]


def main():
    args = parse_args()

    with app_context():
        result = generate_schedule(
            args.year,
            args.month,
            days_off=parse_days_off(args.days_off)
        )

        if result.get("error"):
            raise SystemExit(result["error"])

        rows = [
            (
                item["work_date"],
                item["day"],
                item["user"],
                item["shift"],
                item["pattern"],
                item["user_score"]
            )
            for item in result.get("schedules", [])
        ]
        db.session.rollback()

    print_rows(
        ["date", "day", "user", "shift", "pattern", "score_after"],
        rows
    )


if __name__ == "__main__":
    main()
