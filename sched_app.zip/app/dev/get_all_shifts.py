from app.models.shift import Shift
from app.dev.common import app_context, print_rows


def main():
    with app_context():
        shifts = Shift.query.order_by(Shift.shift_index.asc()).all()
        rows = [
            (
                shift.id,
                shift.shift_index,
                shift.shift_name,
                shift.start_time.strftime("%H:%M"),
                shift.end_time.strftime("%H:%M"),
                shift.score
            )
            for shift in shifts
        ]

    print_rows(
        ["id", "index", "name", "start", "end", "score"],
        rows
    )


if __name__ == "__main__":
    main()
